<?php
session_start();
include('connection.php');

// Handle search query
$search = '';
if (isset($_POST['search'])) {
    $search = $_POST['search'];
    $stmt = $conn->prepare("SELECT * FROM customer_orders WHERE firstname LIKE ? OR lastname LIKE ? ORDER BY order_date DESC");
    $likeSearch = "%{$search}%";
    $stmt->bind_param("ss", $likeSearch, $likeSearch);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    // Fetch all orders if no search query
    $result = $conn->query("SELECT * FROM customer_orders ORDER BY order_date DESC");
}

// Handle CSV download
if (isset($_POST['download_csv'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=customer_orders.csv');
    $output = fopen('php://output', 'w');
    fputcsv($output, array('ID', 'First Name', 'Last Name', 'Gender', 'Telephone', 'Shoes Total', 'Clothes Total', 'Total Order Price', 'Discount Amount', 'Final Total Price', 'Order Date'));

    // Fetch data again for CSV generation (based on search or all orders)
    if (!empty($search)) {
        $stmt = $conn->prepare("SELECT * FROM customer_orders WHERE firstname LIKE ? OR lastname LIKE ? ORDER BY order_date DESC");
        $stmt->bind_param("ss", $likeSearch, $likeSearch);
        $stmt->execute();
        $result_csv = $stmt->get_result();
    } else {
        $result_csv = $conn->query("SELECT * FROM customer_orders ORDER BY order_date DESC");
    }

    while ($row = $result_csv->fetch_assoc()) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit(); // Stop further script execution after the CSV download
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Orders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
        }
        .table-container {
            width: 100%;
            max-width: 1000px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }

        /* Input and button styling */
        input[type="text"] {
            width: 75%; /* Adjust width as needed */
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        input[type="submit"] {
            background-color: #4cae4c; /* Green button color */
            color: white;
            border: none;
            padding: 12px 20px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            margin-left: 10px; /* Space between input and button */
        }
        input[type="submit"]:hover {
            background-color: #45a049; /* Button hover effect */
        }

        /* Button for "Back" */
        .back-button {
            text-decoration: none;
            padding: 10px;
            background-color: #5cb85c;
            color: white;
            border-radius: 5px;
            font-size: 16px;
        }

        /* Button for "Download CSV" */
        .download-button {
            text-decoration: none;
            padding: 10px;
            background-color: #5cb85c;
            color: white;
            border-radius: 5px;
            font-size: 16px;
        }

        /* Update button */
        .update-button {
            background-color: #f0ad4e;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
        }
        .update-button:hover {
            background-color: #ec971f;
        }
    </style>
</head>
<body>

    <h1>Customer Orders</h1>

    <div class="header-container">
        <div>
            <a href="dounlod.php" class="back-button">Back</a>
        </div>
        <div>
            <!-- Search form -->
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" style="display: flex; align-items: center;">
                <input type="text" name="search" placeholder="Search by First or Last Name" value="<?php echo htmlspecialchars($search); ?>">
                <input type="submit" value="Search">
            </form>
        </div>
        <div>
            <!-- Download CSV form -->
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
                <input type="submit" name="download_csv" class="download-button" value="Download CSV">
            </form>
        </div>
    </div>

    <div class="table-container">
        <h2>Existing Orders</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Gender</th>
                <th>Telephone</th>
                <th>Shoes Total</th>
                <th>Clothes Total</th>
                <th>Total Order Price</th>
                <th>Discount Amount</th>
                <th>Final Total Price</th>
                <th>Order Date</th>
                <th>Action</th> <!-- New column for Update button -->
            </tr>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['firstname']; ?></td>
                        <td><?php echo $row['lastname']; ?></td>
                        <td><?php echo $row['gender']; ?></td>
                        <td><?php echo $row['telephone']; ?></td>
                        <td><?php echo $row['shoes_total']; ?></td>
                        <td><?php echo $row['clothes_total']; ?></td>
                        <td><?php echo $row['total_order_price']; ?></td>
                        <td><?php echo $row['discount_amount']; ?></td>
                        <td><?php echo $row['final_total_price']; ?></td>
                        <td><?php echo $row['order_date']; ?></td>
                        <td><a href="update1.php?id=<?php echo $row['id']; ?>" class="update-button">Update</a></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="12" style="text-align: center;">No orders found.</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>

</body>
</html>
