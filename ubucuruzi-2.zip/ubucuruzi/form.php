<?php
session_start(); // Start the session to manage user login
include('connection.php');

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Get form values
    $item_name = $_POST['item_name'];
    $price = $_POST['price'];
    $stock_quantity = $_POST['stock_quantity'];

    // Prepare an insert query using prepared statements
    $stmt = $conn->prepare("INSERT INTO items (item_name, price, stock_quantity) VALUES (?, ?, ?)");
    $stmt->bind_param("sdi", $item_name, $price, $stock_quantity);  // "sdi" - string, double, integer

    // Execute the query
    if ($stmt->execute()) {
        echo "New item inserted successfully";
        header('Location: select.php');
        exit();  // Ensure the script stops after the redirect
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Insert Item</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .welcome {
            text-align: right;
            margin-bottom: 20px;
        }

        table {
            margin: 0 auto;
            border-collapse: collapse;
            width: 50%;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        td {
            padding: 10px;
            border: 1px solid #ddd;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

    <!-- Welcome Message -->
    <div class="welcome">
        <?php echo "Welcome, " . htmlspecialchars($_SESSION['username']) . "!"; ?>
    </div>

    <h1>Insert New Item</h1>
    <form method="POST" action="">
        <table>
            <tr>
                <td>Item Name</td>
                <td><input type="text" name="item_name" required></td>
            </tr>
            <tr>
                <td>Price</td>
                <td><input type="number" name="price" step="0.01" required></td>
            </tr>
            <tr>
                <td>Stock Quantity</td>
                <td><input type="number" name="stock_quantity" required></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="submit" value="Insert"></td>
            </tr>
        </table>
    </form>

</body>
</html>
