<?php

$servername="localhost";
$username="root";
$password="";
$dbname="henriette";
$conn=mysqli_connect("localhost","root","","henriette");
//if ($conn) {
	//echo "connected";
//}
//else
//{
	//echo "not connected";
//}
?>