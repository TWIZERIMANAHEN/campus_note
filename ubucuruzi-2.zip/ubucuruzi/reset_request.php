<?php
session_start();
include('connection.php');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['reset_request'])) {
        // Handle password reset request
        $username = $_POST['username'];

        // Check if the username exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
        if (!$stmt) {
            die("SQL error in preparation: " . $conn->error);
        }
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $token = bin2hex(random_bytes(50)); // Generate a unique token
            $stmt = $conn->prepare("UPDATE users SET reset_token=? WHERE username=?");
            if (!$stmt) {
                die("SQL error in preparation: " . $conn->error);
            }
            $stmt->bind_param("ss", $token, $username);
            $stmt->execute();

            // Send email with reset link
            $reset_link = "http://yourwebsite.com/reset.php?token=" . $token; // Change to your website URL
            if (mail($username, "Password Reset Request", "Click here to reset your password: " . $reset_link)) {
                $success_message = "A reset link has been sent to your email.";
            } else {
                $error_message = "Failed to send email. Please try again later.";
            }
        } else {
            $error_message = "Username not found.";
        }
    } elseif (isset($_POST['reset_password'])) {
        // Handle password reset
        $token = $_POST['token'];
        $new_password = $_POST['new_password'];

        // Verify the token
        $stmt = $conn->prepare("SELECT * FROM users WHERE reset_token=?");
        if (!$stmt) {
            die("SQL error in preparation: " . $conn->error);
        }
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $stmt = $conn->prepare("UPDATE users SET password=?, reset_token=NULL WHERE reset_token=?");
            if (!$stmt) {
                die("SQL error in preparation: " . $conn->error);
            }
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt->bind_param("ss", $hashed_password, $token);
            $stmt->execute();

            $success_message = "Password reset successfully! You can now <a href='login.php'>login</a>.";
        } else {
            $error_message = "Invalid token.";
        }
    }
}
?>

<html>
<head>
    <title>Password Reset</title>
    <style>
        /* Styles for the form */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .form-container {
            width: 300px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="submit"] {
            background-color: #5cb85c;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
            width: 100%;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        .message {
            color: green;
            text-align: center;
        }
        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Password Reset</h1>
        <?php if (isset($_GET['token'])): ?>
            <!-- Password Reset Form -->
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <input type="hidden" name="token" value="<?php echo $_GET['token']; ?>">
                <label for="new_password">New Password:</label>
                <input type="password" name="new_password" required>
                <input type="submit" name="reset_password" value="Reset Password">
            </form>
        <?php else: ?>
            <!-- Reset Request Form -->
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <label for="username">Username:</label>
                <input type="text" name="username" required>
                <input type="submit" name="reset_request" value="Request Reset">
            </form>
        <?php endif; ?>
        
        <!-- Display messages -->
        <?php if (isset($success_message)): ?>
            <div class="message"><?php echo $success_message; ?></div>
        <?php elseif (isset($error_message)): ?>
            <div class="error"><?php echo $error_message; ?></div>
        <?php endif; ?>
    </div>
</body>
</html>
