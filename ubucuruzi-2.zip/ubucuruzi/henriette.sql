-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2024 at 11:44 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `henriette`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_orders`
--

CREATE TABLE `customer_orders` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `gender` enum('male','female','other') NOT NULL,
  `telephone` varchar(15) NOT NULL,
  `shoes_total` decimal(10,2) NOT NULL,
  `clothes_total` decimal(10,2) NOT NULL,
  `total_order_price` decimal(10,2) NOT NULL,
  `discount_amount` decimal(10,2) NOT NULL,
  `final_total_price` decimal(10,2) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_orders`
--

INSERT INTO `customer_orders` (`id`, `firstname`, `lastname`, `gender`, `telephone`, `shoes_total`, `clothes_total`, `total_order_price`, `discount_amount`, `final_total_price`, `order_date`) VALUES
(1, 'wera', 'aline', 'female', '0790083554', '300000.00', '600000.00', '900000.00', '3600.00', '896400.00', '2024-09-20 13:20:00'),
(2, 'wera', 'aline', 'female', '0790083554', '300000.00', '600000.00', '900000.00', '3600.00', '896400.00', '2024-09-20 13:32:17'),
(3, 'wera', 'aline', 'female', '0790083554', '250000.00', '100000.00', '350000.00', '1400.00', '348600.00', '2024-09-20 13:49:18'),
(4, 'wera', 'ewr', 'male', '0790083554', '200000.00', '140000.00', '340000.00', '1360.00', '338640.00', '2024-09-20 14:35:18'),
(5, 'henriette', 'aline', 'female', '0790083554', '30000.00', '4.00', '30004.00', '0.00', '30004.00', '2024-09-20 14:41:12'),
(6, 'IGIRANEZA ', 'Clarisse ', 'female', '0788888888', '200000.00', '6.00', '200006.00', '800.02', '199205.98', '2024-09-20 15:23:16'),
(7, 'IGIRANEZA ', 'Clarisse ', 'female', '0788888888', '30000.00', '60000.00', '90000.00', '180.00', '89820.00', '2024-09-20 15:42:52'),
(8, 'IGIRANEZA ', 'Clarisse ', 'female', '0788888888', '0.00', '0.00', '210000.00', '840.00', '209160.00', '2024-09-23 06:58:13'),
(9, 'IGIRANEZA ', 'Clarisse ', 'female', '0788888888', '0.00', '0.00', '510000.00', '2040.00', '507960.00', '2024-09-23 14:05:43'),
(10, 'ffff', 'gggg', 'female', '0788888888', '0.00', '0.00', '895000.00', '3580.00', '891420.00', '2024-09-23 14:20:58'),
(11, 'wera', 'aline', 'male', '0790083554', '0.00', '0.00', '900.00', '0.00', '900.00', '2024-09-23 18:37:34'),
(12, 'wera', 'aline', 'male', '0790083554', '0.00', '0.00', '240000.00', '960.00', '239040.00', '2024-09-23 18:40:05'),
(13, 'IGIRANEZA ', 'Clarisse ', 'male', '0788888888', '0.00', '0.00', '200000.00', '800.00', '199200.00', '2024-09-24 07:06:39'),
(14, 'IGIRANEZA ', 'gggg', 'male', '0788888888', '0.00', '0.00', '800000.00', '320000.00', '480000.00', '2024-09-24 07:20:43'),
(15, 'henriette', 'aline', 'female', '0790083554', '0.00', '0.00', '20000.00', '0.00', '20000.00', '2024-09-24 08:30:25'),
(16, 'IGIRANEZA ', 'Clarisse ', 'female', '0788888888', '0.00', '0.00', '150000.00', '60000.00', '90000.00', '2024-09-24 08:47:17'),
(17, 'IGIRANEZA ', 'Clarisse ', 'female', '0788888888', '0.00', '0.00', '100000.00', '20000.00', '80000.00', '2024-09-24 09:11:32'),
(18, 'IGIRANEZA ', 'Clarisse ', 'male', '0788888888', '0.00', '0.00', '130000.00', '52000.00', '78000.00', '2024-09-24 09:14:38'),
(19, 'wera', 'aline', 'female', '0790083554', '0.00', '0.00', '100000.00', '20000.00', '80000.00', '2024-09-24 09:24:12'),
(20, 'henriette', 'aline', 'male', '0790083554', '0.00', '0.00', '60000.00', '12000.00', '48000.00', '2024-09-25 07:49:42'),
(21, 'henriette', 'aline', 'male', '0790083554', '0.00', '0.00', '175000.00', '70000.00', '105000.00', '2024-09-25 08:01:31'),
(22, 'henriette', 'aline', 'male', '0790083554', '0.00', '0.00', '475000.00', '190000.00', '285000.00', '2024-09-25 08:05:52');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock_quantity` int(11) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `item_name`, `price`, `stock_quantity`, `image_path`) VALUES
(2, 'Clothes', '20000.00', 1, NULL),
(3, 'Shoes', '15000.00', 45, NULL),
(4, 'Clothes', '2.00', 145, NULL),
(5, 'Jackets', '20000.00', 4962, NULL),
(6, 'Dress Shoes', '50000.00', 0, NULL),
(7, 'Sandals', '20000.00', 15, NULL),
(8, 'High-Tops', '30000.00', 12, NULL),
(9, 'Hiking Shoes', '60000.00', 8, NULL),
(10, 'Boots', '55000.00', 10, NULL),
(11, 'Casual Shoes', '45000.00', 23, NULL),
(12, 'Formal Clothes', '70000.00', 16, NULL),
(13, 'T-Shirts', '15000.00', 38, NULL),
(14, 'Jeans', '25000.00', 24, NULL),
(15, 'Jackets', '80000.00', 17, NULL),
(16, 'Dress Shoes', '50000.00', 10, 'download '),
(17, 'Sandals', '20000.00', 26, 'download (1)'),
(18, 'High-Tops', '30000.00', 13, 'download (2)'),
(19, 'Clothes', '20000.00', 78, NULL),
(20, 'Clothes', '20000.00', 7, NULL),
(21, 'shoes', '20000.00', 3, NULL),
(22, 'shoes', '20000.00', 5, NULL),
(23, 'Inkweto size 8', '25750.00', 12, NULL),
(24, 'amazi', '300.00', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `item_id`, `quantity`, `total_price`, `order_date`) VALUES
(2, 2, 3, '60000.00', '2024-09-20 12:43:20'),
(3, 3, 10, '150000.00', '2024-09-20 12:59:28'),
(4, 2, 20, '400000.00', '2024-09-20 12:59:28'),
(5, 3, 20, '300000.00', '2024-09-20 13:20:00'),
(6, 2, 30, '600000.00', '2024-09-20 13:20:00'),
(7, 3, 20, '300000.00', '2024-09-20 13:32:17'),
(8, 2, 30, '600000.00', '2024-09-20 13:32:17'),
(10, 2, 5, '100000.00', '2024-09-20 13:49:18'),
(12, 2, 7, '140000.00', '2024-09-20 14:35:18'),
(13, 3, 2, '30000.00', '2024-09-20 14:41:12'),
(14, 4, 2, '4.00', '2024-09-20 14:41:12'),
(16, 4, 3, '6.00', '2024-09-20 15:23:16'),
(17, 3, 2, '30000.00', '2024-09-20 15:42:52'),
(18, 2, 3, '60000.00', '2024-09-20 15:42:52'),
(20, 2, 3, '60000.00', '2024-09-23 06:58:13'),
(21, 5, 2, '0.00', '2024-09-23 06:58:13'),
(22, 6, 3, '150000.00', '2024-09-23 14:05:43'),
(23, 7, 2, '40000.00', '2024-09-23 14:05:43'),
(24, 8, 1, '30000.00', '2024-09-23 14:05:43'),
(25, 9, 1, '60000.00', '2024-09-23 14:05:43'),
(26, 10, 1, '55000.00', '2024-09-23 14:05:43'),
(27, 11, 1, '45000.00', '2024-09-23 14:05:43'),
(28, 12, 1, '70000.00', '2024-09-23 14:05:43'),
(29, 13, 1, '15000.00', '2024-09-23 14:05:43'),
(30, 14, 1, '25000.00', '2024-09-23 14:05:43'),
(31, 5, 1, '20000.00', '2024-09-23 14:05:43'),
(32, 16, 10, '500000.00', '2024-09-23 14:20:58'),
(33, 7, 1, '20000.00', '2024-09-23 14:20:58'),
(34, 8, 2, '60000.00', '2024-09-23 14:20:58'),
(35, 9, 1, '60000.00', '2024-09-23 14:20:58'),
(36, 10, 1, '55000.00', '2024-09-23 14:20:58'),
(37, 11, 1, '45000.00', '2024-09-23 14:20:58'),
(38, 12, 1, '70000.00', '2024-09-23 14:20:58'),
(39, 13, 1, '15000.00', '2024-09-23 14:20:58'),
(40, 14, 2, '50000.00', '2024-09-23 14:20:58'),
(41, 5, 1, '20000.00', '2024-09-23 14:20:58'),
(42, 24, 3, '900.00', '2024-09-23 18:37:34'),
(43, 2, 0, '0.00', '2024-09-23 18:37:34'),
(44, 5, 0, '0.00', '2024-09-23 18:37:34'),
(45, 6, 0, '0.00', '2024-09-23 18:37:34'),
(46, 7, 0, '0.00', '2024-09-23 18:37:34'),
(47, 9, 0, '0.00', '2024-09-23 18:37:34'),
(48, 10, 0, '0.00', '2024-09-23 18:37:34'),
(49, 7, 12, '240000.00', '2024-09-23 18:40:05'),
(50, 2, 0, '0.00', '2024-09-23 18:40:05'),
(51, 5, 0, '0.00', '2024-09-23 18:40:05'),
(52, 6, 0, '0.00', '2024-09-23 18:40:05'),
(53, 7, 0, '0.00', '2024-09-23 18:40:05'),
(54, 9, 0, '0.00', '2024-09-23 18:40:05'),
(55, 10, 0, '0.00', '2024-09-23 18:40:05'),
(56, 6, 4, '200000.00', '2024-09-24 07:06:39'),
(57, 2, 0, '0.00', '2024-09-24 07:06:39'),
(58, 5, 0, '0.00', '2024-09-24 07:06:39'),
(59, 6, 0, '0.00', '2024-09-24 07:06:39'),
(60, 7, 0, '0.00', '2024-09-24 07:06:39'),
(61, 9, 0, '0.00', '2024-09-24 07:06:39'),
(62, 10, 0, '0.00', '2024-09-24 07:06:39'),
(63, 6, 2, '100000.00', '2024-09-24 07:20:43'),
(64, 2, 1, '20000.00', '2024-09-24 07:20:43'),
(65, 5, 34, '680000.00', '2024-09-24 07:20:43'),
(66, 2, 1, '20000.00', '2024-09-24 08:30:25');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `created_at`) VALUES
(0, 'admin', '123', '2024-09-22 14:54:57'),
(0, 'Client', '$2y$10$NxbHJP2Xs0uAgk5hPE/uauBBm7s0aQlk.mKTgOWsPmlUuETBGbekW', '2024-09-22 14:55:14'),
(0, 'admin', '$2y$10$/LXtRjFZ9Q.l3Y5AZRifPuQmOA68v.Xejg.hw//XXImhsGf7O/eYi', '2024-09-22 15:04:43'),
(0, 'wera', '1234e', '2024-09-22 18:28:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `reset_token`) VALUES
(1, 'twizerimanahenrette@gmail.com', '$2y$10$nTexA12vBcAjdymN/u5zjuVd9b/jtEne5nnfBAQSMy1uw3aLGmaJC', 'admin', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_orders`
--
ALTER TABLE `customer_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_ibfk_1` (`item_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_orders`
--
ALTER TABLE `customer_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
