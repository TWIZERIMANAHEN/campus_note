<!DOCTYPE html>
<html>

<head>
    <title>Update Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        table {
            margin: 0 auto;
            border-collapse: collapse;
            width: 50%;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        td {
            padding: 10px;
            border: 1px solid #ddd;
        }
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include("connection.php");
$id = $_GET['id'];

$select = mysqli_query($conn, "SELECT * FROM items WHERE id='$id'");
$row = mysqli_num_rows($select);
if ($row > 0) {
    while ($henry = mysqli_fetch_array($select)) {
?>
<body>
    <form method="POST">
        <h1>Update Form</h1>
        <table>
            <tr>
                <td>ITEM_NAME</td>
                <td>
                    <input type="text" name="item_name" value="<?php echo $henry['item_name']; ?>">
                </td>
            </tr>
            <tr>
                <td>PRICE</td>
                <td>
                    <input type="text" name="price" value="<?php echo $henry['price']; ?>">
                </td>
            </tr>
            <tr>
                <td>STOCK_QUANTITY</td>
                <td>
                    <input type="number" name="stock_quantity" value="<?php echo $henry['stock_quantity']; ?>">
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type="submit" name="update" value="Update">
                    <input type="submit" name="order" value="Order">
                </td>
            </tr>
        </table>    
    </form>
</body>
</html>
<?php
    }
}

if (isset($_POST['update'])) {
    $item_name = $_POST['item_name'];
    $price = $_POST['price'];
    $stock_quantity = $_POST['stock_quantity'];
   
    $sqli = mysqli_query($conn, "UPDATE items SET item_name='$item_name', price='$price', stock_quantity='$stock_quantity' WHERE id='$id'");

    if ($sqli) {
        header('location:select.php');
        echo "Data updated";
    } else {
        echo "Data not updated: " . mysqli_error($conn);  
    }
}

if (isset($_POST['order'])) {
    // Decrease stock quantity by 1
    $current_stock = mysqli_fetch_assoc(mysqli_query($conn, "SELECT stock_quantity FROM items WHERE id='$id'"))['stock_quantity'];
    
    if ($current_stock > 0) {
        $new_stock_quantity = $current_stock - 1;
        $order_sql = mysqli_query($conn, "UPDATE items SET stock_quantity='$new_stock_quantity' WHERE id='$id'");
        
        if ($order_sql) {
            header('location:select.php');
            echo "Order placed successfully!";
        } else {
            echo "Order not processed: " . mysqli_error($conn);
        }
    } else {
        echo "Insufficient stock to place an order.";
    }
}
?>
