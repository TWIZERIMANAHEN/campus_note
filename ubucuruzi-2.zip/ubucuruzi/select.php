<?php
session_start();

// Prevent caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$timeout_duration = 900; // 15 minutes in seconds

// Check if the session is set and if it has timed out
if (isset($_SESSION['LAST_ACTIVITY'])) {
    if (time() - $_SESSION['LAST_ACTIVITY'] > $timeout_duration) {
        session_unset(); 
        session_destroy();
        header('Location: index.php'); // Redirect to login if session has expired
        exit();
    }
}

// Update last activity time
$_SESSION['LAST_ACTIVITY'] = time();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: index.php'); // Redirect to login if not logged in
    exit();
}

include('connection.php');

$search = '';
if (isset($_POST['search'])) {
    $search = mysqli_real_escape_string($conn, $_POST['search']);
}

$select = mysqli_query($conn, "SELECT * FROM items WHERE item_name LIKE '%$search%' OR price LIKE '%$search%' OR stock_quantity LIKE '%$search%'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Item Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #4CAF50;
            padding: 10px;
            color: white;
        }
        .header .welcome {
            font-weight: bold;
        }
        .header a {
            text-decoration: none;
            color: white;
            font-weight: bold;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #ddd;
        }
        td a {
            color: #4CAF50;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        td a:hover {
            background-color: #4CAF50;
            color: white;
        }
        form {
            margin: 20px auto;
            text-align: center;
        }
        input[type="text"] {
            padding: 8px;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            padding: 8px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

    <div class="header">
        <div class="welcome">
            <?php echo "Welcome, " . htmlspecialchars($_SESSION['username']); ?>
        </div>
        <div>
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <form method="POST">
        <input type="text" name="search" placeholder="Search by item name..." value="<?php echo htmlspecialchars($search); ?>">
        <input type="submit" value="Search">
    </form>
    
    <table border="2px">
        <tr>        
            <th>Item Name</th>
            <th>Price</th> 
            <th>Stock Quantity</th>
            <th colspan='2'>Action</th>
        </tr>

        <?php
        while ($fetch = mysqli_fetch_array($select)) {
            $id = $fetch['id'];
            echo "<tr>
                <td>".$fetch['item_name']."</td>
                <td>".$fetch['price']."</td>
                <td>".$fetch['stock_quantity']."</td>
                <td><a href='update.php?id=$id'>Update</a></td>
                <td><a href='delete.php?id=$id'>Delete</a></td>
            </tr>";
        }
        ?>
    </table>
</body>
</html>
