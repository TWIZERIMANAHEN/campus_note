<?php
session_start();
include('connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: auto;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }

        input[type="text"],
        input[type="tel"],
        input[type="number"],
        select {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="checkbox"] {
            margin-bottom: 10px;
        }

        button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        button:hover {
            background-color: #218838;
        }

        .field-group {
            margin-left: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        tfoot td {
            font-weight: bold;
        }
    </style>
    <meta charset="UTF-8">
    <title>Order Form</title>
</head>
<body>
    <form action="invoice.php" method="POST">
        <h1>Order Shoes, Clothes, and Jackets</h1>

        <!-- Customer details -->
        <label for="firstname">First Name:</label>
        <input type="text" name="firstname" required><br>

        <label for="lastname">Last Name:</label>
        <input type="text" name="lastname" required><br>

        <label for="gender">Gender:</label>
        <select name="gender" required>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
        </select><br>

        <label for="telephone">Telephone:</label>
        <input type="tel" name="telephone" required><br>

        <!-- Shoes selection -->
        <div id="shoes_section">
            <label>Order Shoes:</label>
            <div class="field-group" id="shoes_fields">
                <label for="shoes_id">Select Shoes:</label>
                <select name="shoes_id[]">
                    <?php
                    $items = $conn->query("SELECT * FROM items WHERE item_name IN ('Dress Shoes', 'Sandals', 'High-Tops', 'Hiking Shoes', 'Boots') AND stock_quantity > 0");
                    while ($row = $items->fetch_assoc()) {
                        echo "<option value='" . $row['id'] . "'>" . $row['item_name'] . " (Stock: " . $row['stock_quantity'] . ") - Price: FRW " . number_format($row['price'], 2) . "</option>";
                    }
                    ?>
                </select><br>

                <label for="shoes_quantity">Shoes Quantity:</label>
                <input type="number" name="shoes_quantity[]" min="1" max="100"><br>
            </div>
            <button type="button" onclick="addMoreFields('shoes')">Add More Shoes</button><br><br>
        </div>

        <!-- Clothes selection -->
        <div id="clothes_section">
            <label>Order Clothes:</label>
            <div class="field-group" id="clothes_fields">
                <label for="clothes_id">Select Clothes:</label>
                <select name="clothes_id[]">
                    <?php
                    $items = $conn->query("SELECT * FROM items WHERE item_name IN ('T-Shirt', 'Jeans', 'Jacket', 'Sweater', 'Coat') AND stock_quantity > 0");
                    while ($row = $items->fetch_assoc()) {
                        echo "<option value='" . $row['id'] . "'>" . $row['item_name'] . " (Stock: " . $row['stock_quantity'] . ") - Price: FRW " . number_format($row['price'], 2) . "</option>";
                    }
                    ?>
                </select><br>

                <label for="clothes_quantity">Clothes Quantity:</label>
                <input type="number" name="clothes_quantity[]" min="1" max="100"><br>
            </div>
            <button type="button" onclick="addMoreFields('clothes')">Add More Clothes</button><br><br>
        </div>

        <!-- Jackets selection -->
        <div id="jackets_section">
            <label>Order Jackets:</label>
            <div class="field-group" id="jackets_fields">
                <label for="jackets_id">Select Jackets:</label>
                <select name="jackets_id[]">
                    <?php
                    $items = $conn->query("SELECT * FROM items WHERE item_name IN ('Leather Jacket','Jackets', 'Denim Jacket', 'Windbreaker', 'Puffer Jacket', 'Rain Jacket') AND stock_quantity > 0");
                    while ($row = $items->fetch_assoc()) {
                        echo "<option value='" . $row['id'] . "'>" . $row['item_name'] . " (Stock: " . $row['stock_quantity'] . ") - Price: FRW " . number_format($row['price'], 2) . "</option>";
                    }
                    ?>
                </select><br>

                <label for="jackets_quantity">Jackets Quantity:</label>
                <input type="number" name="jackets_quantity[]" min="1" max="100"><br>
            </div>
            <button type="button" onclick="addMoreFields('jackets')">Add More Jackets</button><br><br>
        </div>

        <button type="submit" name="order">Place Order</button>
    </form>

    <script>
        function addMoreFields(section) {
            var sectionId = section + "_fields";
            var sectionElement = document.getElementById(sectionId);
            var clone = sectionElement.cloneNode(true);
            document.getElementById(section + "_section").appendChild(clone);
        }
    </script>
</body>
</html>
