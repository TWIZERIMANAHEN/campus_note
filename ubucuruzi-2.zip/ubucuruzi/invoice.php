<?php
session_start();
include('connection.php');

if (isset($_POST['order'])) {
    // Get customer information
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $gender = $_POST['gender'];
    $telephone = $_POST['telephone'];

    // Initialize order total
    $total_order_price = 0;
    $order_items = []; // Array to store ordered items

    // Function to process the order for an item
    function processOrder($conn, $item_id, $quantity) {
        $stmt = $conn->prepare("SELECT * FROM items WHERE id=?");
        if ($stmt === false) {
            die("Error preparing item query: " . $conn->error);
        }
        $stmt->bind_param("i", $item_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $item = $result->fetch_assoc();

        if ($item && $item['stock_quantity'] >= $quantity) {
            $total_price = $item['price'] * $quantity;

            // Store order item details, including the `item_id` directly
            $order_item = [
                'id' => $item['id'],  // Storing item ID directly
                'name' => $item['item_name'],
                'price' => $item['price'],
                'quantity' => $quantity,
                'total' => $total_price
            ];

            // Update stock quantity
            $new_stock_quantity = $item['stock_quantity'] - $quantity;
            $update_stock = $conn->prepare("UPDATE items SET stock_quantity=? WHERE id=?");
            if ($update_stock === false) {
                die("Error preparing stock update query: " . $conn->error);
            }
            $update_stock->bind_param("ii", $new_stock_quantity, $item_id);
            $update_stock->execute();

            return $order_item;
        } else {
            return false; // Not enough stock
        }
    }

    // Process items (Shoes, Clothes, Jackets)
    $categories = ['shoes', 'clothes', 'jackets'];
    foreach ($categories as $category) {
        if (isset($_POST[$category . '_id']) && !empty($_POST[$category . '_quantity'])) {
            $item_ids = $_POST[$category . '_id'];
            $quantities = $_POST[$category . '_quantity'];

            foreach ($item_ids as $index => $item_id) {
                if (!empty($quantities[$index])) {
                    $quantity = $quantities[$index];
                    $order_item = processOrder($conn, $item_id, $quantity);
                    if ($order_item !== false) {
                        $order_items[] = $order_item;
                        $total_order_price += $order_item['total'];
                    } else {
                        echo "<p>Not enough stock available for " . ucfirst($category) . ".</p>";
                    }
                }
            }
        }
    }

    // Apply discount based on total order price
    $discount_percentage = ($total_order_price > 100000) ? 0.4 : (($total_order_price > 50000) ? 0.2 : 0);
    $discount_amount = $total_order_price * $discount_percentage;
    $final_total_price = $total_order_price - $discount_amount;

    // If the order is successful, insert into the database and display the invoice
    if ($total_order_price > 0) {
        // Insert customer order into the database
        $stmt = $conn->prepare("INSERT INTO customer_orders (firstname, lastname, gender, telephone, total_order_price, discount_amount, final_total_price) VALUES (?, ?, ?, ?, ?, ?, ?)");
        if ($stmt === false) {
            die("Error preparing customer order query: " . $conn->error);
        }
        $stmt->bind_param("ssssddd", $firstname, $lastname, $gender, $telephone, $total_order_price, $discount_amount, $final_total_price);
        $stmt->execute();
        $order_id = $stmt->insert_id; // Get the inserted order ID

        // Insert order items into order_items table
        foreach ($order_items as $item) {
            $stmt = $conn->prepare("INSERT INTO order_items (order_id, item_id, quantity) VALUES (?, ?, ?)");
            if ($stmt === false) {
                die("Error preparing order item query: " . $conn->error);
            }
            $stmt->bind_param("iii", $order_id, $item['id'], $item['quantity']);
            $stmt->execute();
        }

        // Generate Invoice (same as before)
        // ...
    } else {
        echo "<p>Order failed. Please try again.</p>";
    }
}
?>
