<?php
session_start();
include('connection.php');

// Check if the ID is provided via GET request
if (isset($_GET['id'])) {
    $order_id = $_GET['id'];

    // Fetch the customer order details based on the ID
    $stmt = $conn->prepare("SELECT * FROM customer_orders WHERE id = ?");
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $order = $result->fetch_assoc();

    if (!$order) {
        echo "Order not found!";
        exit();
    }
} else {
    echo "No order ID provided!";
    exit();
}

// Handle form submission for updating order details
if (isset($_POST['update_order'])) {
    // Get updated data from the form
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $gender = $_POST['gender'];
    $telephone = $_POST['telephone'];
    $shoes_total = $_POST['shoes_total'];
    $clothes_total = $_POST['clothes_total'];
    $total_order_price = $_POST['total_order_price'];
    $discount_amount = $_POST['discount_amount'];
    $final_total_price = $_POST['final_total_price'];
    $order_date = $_POST['order_date'];

    // Prepare the SQL query to update the order
    $stmt = $conn->prepare("UPDATE customer_orders SET firstname=?, lastname=?, gender=?, telephone=?, shoes_total=?, clothes_total=?, total_order_price=?, discount_amount=?, final_total_price=?, order_date=? WHERE id=?");
    $stmt->bind_param("ssssddddssi", $firstname, $lastname, $gender, $telephone, $shoes_total, $clothes_total, $total_order_price, $discount_amount, $final_total_price, $order_date, $order_id);

    // Execute the update query
    if ($stmt->execute()) {
        echo "Order updated successfully!";
        header('Location: view.php'); // Redirect to main page or wherever needed
        exit();
    } else {
        echo "Error updating order: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Order</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-top: 10px;
            font-weight: bold;
        }
        input, select {
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px;
        }
        button:hover {
            background-color: #218838;
        }
        a {
            text-decoration: none;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            display: inline-block;
            margin-top: 10px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Update Order</h2>

        <form action="" method="POST">
            <label for="firstname">First Name</label>
            <input type="text" name="firstname" id="firstname" value="<?php echo htmlspecialchars($order['firstname']); ?>" required>

            <label for="lastname">Last Name</label>
            <input type="text" name="lastname" id="lastname" value="<?php echo htmlspecialchars($order['lastname']); ?>" required>

            <label for="gender">Gender</label>
            <select name="gender" id="gender" required>
                <option value="Male" <?php echo ($order['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                <option value="Female" <?php echo ($order['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
            </select>

            <label for="telephone">Telephone</label>
            <input type="text" name="telephone" id="telephone" value="<?php echo htmlspecialchars($order['telephone']); ?>" required>

            <label for="shoes_total">Shoes Total</label>
            <input type="number" name="shoes_total" id="shoes_total" value="<?php echo htmlspecialchars($order['shoes_total']); ?>" required>

            <label for="clothes_total">Clothes Total</label>
            <input type="number" name="clothes_total" id="clothes_total" value="<?php echo htmlspecialchars($order['clothes_total']); ?>" required>

            <label for="total_order_price">Total Order Price</label>
            <input type="number" name="total_order_price" id="total_order_price" value="<?php echo htmlspecialchars($order['total_order_price']); ?>" required>

            <label for="discount_amount">Discount Amount</label>
            <input type="number" name="discount_amount" id="discount_amount" value="<?php echo htmlspecialchars($order['discount_amount']); ?>" required>

            <label for="final_total_price">Final Total Price</label>
            <input type="number" name="final_total_price" id="final_total_price" value="<?php echo htmlspecialchars($order['final_total_price']); ?>" required>

            <label for="order_date">Order Date</label>
            <input type="date" name="order_date" id="order_date" value="<?php echo htmlspecialchars($order['order_date']); ?>" required>

            <button type="submit" name="update_order">Update Order</button>
        </form>

        
    </div>

</body>
</html>
