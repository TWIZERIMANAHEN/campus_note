<?php
session_start();
include('connection.php');

// Handle login
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validate that the username is a valid email
    if (!filter_var($username, FILTER_VALIDATE_EMAIL)) {
        $login_error = "Please enter a valid email address.";
    } 
    // Validate the password: must contain at least one letter, one number, and one special character
    elseif (!preg_match('/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password)) {
        $login_error = "Password must be at least 8 characters long, and include at least one letter, one number, and one special character.";
    } 
    else {
        // Ensure the query is secure by using prepared statements
        $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $fetch = $result->fetch_assoc();
            // Verify password using password_verify
            if (password_verify($password, $fetch['password'])) {
                $_SESSION['username'] = $username;
                $_SESSION['role'] = $fetch['role']; // Store user role in session

                // Redirect based on user role
                if ($fetch['role'] == 'admin') {
                    header('location:dounlod.php');
                } elseif ($fetch['role'] == 'user') {
                    header('location:welcome.php');
                }
                exit();
            } else {
                $login_error = "Invalid username or password";
            }
        } else {
            $login_error = "Invalid username or password";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .form-container {
            width: 300px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="submit"] {
            background-color: #5cb85c;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
            width: 100%;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Login</h1>
        <?php if (isset($login_error)): ?>
            <div class="error"><?php echo $login_error; ?></div>
        <?php endif; ?>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <label for="username">Email:</label>
            <input type="text" name="username" required>
            
            <label for="password">Password:</label>
            <input type="password" name="password" required>

            <input type="submit" name="login" value="Login">
        </form>
        <p style="text-align:center;"><a href="create.php">Create an Account</a> <a href="reset_request.php">Forgot Password?</a></p>
    </div>
</body>
</html>
