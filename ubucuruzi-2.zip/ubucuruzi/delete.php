
<?php
session_start();

if (!isset($_SESSION['username'])) {
    // Redirect to login if session is not set
    header("Location: login.php");
    exit();
}

include('connection.php');  

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete query
    $delete = mysqli_query($conn, "DELETE FROM items WHERE id='$id'");

    if ($delete) {
    	header('location:select.php');
        echo "Record deleted successfully.";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    echo "No ID specified.";
}

// Close the database connection
mysqli_close($conn);
?>
